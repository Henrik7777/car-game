let start = document.querySelector(".game .back button");
let back = document.querySelector(".back");
let car1 = document.querySelector(".car1");
let car2 = document.querySelector(".car2");
let car3 = document.querySelector(".car3");
let car4 = document.querySelector(".car4");

let car1Speed = 0;
let car2Speed = 0;
let car3Speed = 0;
let car4Speed = 0;
start.onclick = function() {
    start.style.display = 'none';
    back.style = "animation: back-start 10s linear infinite; top: 0"; 
 let i1 = setInterval(function(){
   car1Speed += Math.random() * 6;
    car1.style.left = car1Speed + 'px';
    car2Speed += Math.random() * 6;
    car2.style.left = car2Speed + 'px';
    car3Speed += Math.random() * 6;
    car3.style.left = car3Speed + 'px';
    car4Speed += Math.random() * 6;
    car4.style.left = car4Speed + 'px';
     if (car1Speed >= window.innerWidth - 280) {
         clearInterval(i1);
         setTimeout(function(){
            window.location.reload();
         },3000)
         winner.style = 'display: block; color: red';
         winner.textContent = 'Red car win';
         back.style = "animation: 0; top: 0"; 
     }
     if (car2Speed >= window.innerWidth - 280) {
        clearInterval(i1);
        setTimeout(function(){
            window.location.reload();
         },2000)
         winner.style = 'display: block; color: blue';
         winner.textContent = 'Blue car win';
         back.style = "animation: 0; top: 0"; 
    }
    if (car3Speed >= window.innerWidth - 280) {
        clearInterval(i1);
        setTimeout(function(){
            window.location.reload();
         },2000)
         winner.style = 'display: block; color: yellow';
         winner.textContent = 'Yellow car win';
         back.style = "animation: 0; top: 0"; 
    }
    if (car4Speed >= window.innerWidth - 280) {
        clearInterval(i1);
        setTimeout(function(){
            window.location.reload();
         },2000)
         winner.style = 'display: block; color: orange';
         winner.textContent = 'Orange car win';
         back.style = "animation: 0; top: 0"; 
    }
    },1);

}
